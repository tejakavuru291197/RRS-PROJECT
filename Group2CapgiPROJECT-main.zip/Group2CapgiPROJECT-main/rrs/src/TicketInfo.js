import React from 'react'

function TicketInfo() {
  return (
    <div><h1>Ticket Information</h1></div>
  )
}

export default TicketInfo